% function loop_Challenge

fprintf(' Loop_Challenge in CINC20_Chall_RB **** \n');


  driver_0(' ', dir_CINC1,'RIS_IVAYLO');   % A
    
  driver_0(' ', dir_CINC2,'RIS_IVAYLO');   % Q
  
  driver_0(' ', dir_CINC6,'RIS_IVAYLO');   % E
  
 driver_0(' ', dir_CINC5,'RIS_IVAYLO');     % H
 
 driver_0(' ', dir_CINC4,'RIS_IVAYLO');     % S
  
 driver_0(' ', dir_CINC3,'RIS_IVAYLO');     % I
 
 
 